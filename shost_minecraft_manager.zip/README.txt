========================================
           ⚡ S.HOST MANAGER ⚡
========================================

Eigenschaften:
- Kein Google Cloud / API Key Setup nötig!
- Kopiere einfach einen Google Drive Freigabe-Link deiner world.zip in die UI.
- Unterstützt Java & Bedrock Crossplay (Konsolen/Handy).
- Integrierte Live-Konsole & Befehlseingabe.

Schnellstart:
1. Pakete installieren:
   pip install -r requirements.txt

2. S.HOST starten:
   python shost.py

3. Browser öffnen: http://localhost:5000
