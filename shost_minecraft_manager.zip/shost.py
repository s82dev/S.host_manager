import os
import subprocess
import threading
import urllib.request
import zipfile
import re
from flask import Flask, render_template_string, request, jsonify

# ==========================================
#              S.HOST CONFIG
# ==========================================
RAM = "2G"
WORLD_FOLDER = "world"

# Paper & Crossplay URLs
PAPER_URL = "https://api.papermc.io/v2/projects/paper/versions/1.20.4/builds/496/downloads/paper-1.20.4-496.jar"
GEYSER_URL = "https://download.geysermc.org/v2/projects/geyser/versions/latest/builds/latest/downloads/spigot"
FLOODGATE_URL = "https://download.geysermc.org/v2/projects/geyser/versions/latest/builds/latest/downloads/floodgate-spigot"

app = Flask(__name__)
server_process = None
tunnel_process = None
console_logs = []

def log(msg):
    clean_msg = f"[S.HOST] {msg}"
    console_logs.append(clean_msg)
    if len(console_logs) > 300:
        console_logs.pop(0)

# --- PUBLIC GOOGLE DRIVE LINK DOWNLOAD ---
def extract_gdrive_file_id(url):
    """Extrahiert die File ID aus normalen Google Drive Teilen-Links."""
    match = re.search(r'/d/([a-zA-Z0-9_-]+)', url)
    if match:
        return match.group(1)
    match = re.search(r'id=([a-zA-Z0-9_-]+)', url)
    if match:
        return match.group(1)
    return url.strip()

def download_world_from_drive_link(drive_url):
    if not drive_url:
        log("Kein Google Drive Link angegeben. Starte ohne welt.zip Download.")
        return

    file_id = extract_gdrive_file_id(drive_url)
    download_url = f"https://drive.google.com/uc?export=download&id={file_id}"
    target_zip = "downloaded_world.zip"

    log("Lade Welt-Archiv über Google Drive Link herunter...")
    try:
        urllib.request.urlretrieve(download_url, target_zip)
        if zipfile.is_zipfile(target_zip):
            with zipfile.ZipFile(target_zip, 'r') as zip_ref:
                zip_ref.extractall(".")
            log("Welt erfolgreich heruntergeladen und entpackt!")
            os.remove(target_zip)
        else:
            log("Fehler: Der Link lieferte keine gültige ZIP-Datei (Zugriff evt. nicht auf 'Jeder mit dem Link' gestellt?).")
    except Exception as e:
        log(f"Fehler beim Download der Welt: {e}")

# --- SERVER DOWNLOAD & MANAGEMENT ---
def setup_server_files(mode):
    if not os.path.exists("eula.txt"):
        with open("eula.txt", "w") as f:
            f.write("eula=true\n")
            
    if mode in ["java", "crossplay"]:
        if not os.path.exists("server.jar"):
            log("Lade Paper Spigot Server herunter...")
            urllib.request.urlretrieve(PAPER_URL, "server.jar")
            
    if mode == "crossplay":
        os.makedirs("plugins", exist_ok=True)
        geyser_path = os.path.join("plugins", "Geyser-Spigot.jar")
        floodgate_path = os.path.join("plugins", "floodgate-spigot.jar")
        if not os.path.exists(geyser_path):
            log("Lade GeyserMC (Bedrock Crossplay) herunter...")
            urllib.request.urlretrieve(GEYSER_URL, geyser_path)
        if not os.path.exists(floodgate_path):
            log("Lade Floodgate herunter...")
            urllib.request.urlretrieve(FLOODGATE_URL, floodgate_path)

def read_output(process):
    for line in iter(process.stdout.readline, ''):
        if line:
            clean_line = line.strip()
            console_logs.append(clean_line)
            if len(console_logs) > 300:
                console_logs.pop(0)

def start_server_logic(mode, drive_url):
    global server_process, tunnel_process
    if server_process is None or server_process.poll() is not None:
        if drive_url:
            download_world_from_drive_link(drive_url)

        setup_server_files(mode)

        # Start Playit.gg Tunnel falls vorhanden
        if os.path.exists("./playit") or os.path.exists("playit.exe"):
            tunnel_cmd = "./playit" if os.name != 'nt' else "playit.exe"
            tunnel_process = subprocess.Popen([tunnel_cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            log("Playit.gg Custom IP Tunnel gestartet!")

        # Start Minecraft Java / Crossplay
        cmd = ["java", f"-Xmx{RAM}", f"-Xms{RAM}", "-jar", "server.jar", "nogui"]
        server_process = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        threading.Thread(target=read_output, args=(server_process,), daemon=True).start()

def stop_server_logic():
    global server_process, tunnel_process
    if server_process and server_process.poll() is None:
        server_process.stdin.write("stop\n")
        server_process.stdin.flush()
        server_process.wait()
        if tunnel_process:
            tunnel_process.terminate()
        log("Server gestoppt!")

# --- WEB UI HTML ---
HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <title>S.HOST - Minecraft Server Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0f111a; color: #e1e6ed; margin: 0; padding: 20px; }
        .header { display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #1f2430; padding-bottom: 15px; margin-bottom: 20px; }
        .logo { font-size: 24px; font-weight: bold; color: #00e676; letter-spacing: 2px; }
        .card { background: #181b28; padding: 20px; border-radius: 8px; border: 1px solid #23283b; margin-bottom: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.3); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 14px; color: #a0a8c0; }
        input[type="text"], select { width: 100%; padding: 12px; background: #0f111a; color: #fff; border: 1px solid #2c3248; border-radius: 6px; box-sizing: border-box; font-size: 14px; }
        input[type="text"]:focus, select:focus { border-color: #00e676; outline: none; }
        .btn-group { display: flex; gap: 10px; margin-top: 15px; }
        .btn { flex: 1; padding: 12px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 15px; transition: background 0.2s; }
        .btn-start { background: #00e676; color: #000; }
        .btn-start:hover { background: #00c853; }
        .btn-stop { background: #ff5252; color: #fff; }
        .btn-stop:hover { background: #d50000; }
        #console { background: #08090d; height: 380px; overflow-y: scroll; padding: 15px; border-radius: 6px; border: 1px solid #1c2030; font-family: 'Courier New', Courier, monospace; font-size: 13px; color: #00e676; line-height: 1.5; }
        .cmd-bar { display: flex; gap: 10px; margin-top: 10px; }
        .cmd-bar input { flex: 1; }
        .cmd-bar button { width: 100px; background: #29b6f6; color: #000; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">⚡ S.HOST</div>
        <div style="font-size: 12px; color: #888;">Minecraft Test-Server Control Center</div>
    </div>

    <div class="card">
        <div class="form-group">
            <label>Google Drive Welt-Link (Freigabe-Link zur world.zip):</label>
            <input type="text" id="driveLink" placeholder="https://drive.google.com/file/d/XYZ.../view?usp=sharing">
        </div>
        
        <div class="form-group">
            <label>Server-Modus:</label>
            <select id="serverMode">
                <option value="crossplay">Crossplay (Java + Bedrock / Konsolen, Mobile & PC)</option>
                <option value="java">Nur Java Edition (PC)</option>
            </select>
        </div>

        <div class="btn-group">
            <button class="btn btn-start" onclick="startServer()">▶ Server Starten</button>
            <button class="btn btn-stop" onclick="stopServer()">⏹ Server Stoppen</button>
        </div>
    </div>

    <div class="card">
        <label>Live Server-Konsole:</label>
        <div id="console"></div>
        <div class="cmd-bar">
            <input type="text" id="cmd" placeholder="Befehl eingeben (z. B. op MeinName, gamemode creative)..." onkeydown="if(event.key==='Enter') sendCmd()">
            <button onclick="sendCmd()">Senden</button>
        </div>
    </div>

    <script>
        function updateLogs() {
            fetch('/logs').then(r => r.json()).then(d => {
                const c = document.getElementById('console');
                c.innerHTML = d.logs.join('<br>');
                c.scrollTop = c.scrollHeight;
            });
        }
        function startServer() {
            const mode = document.getElementById('serverMode').value;
            const link = encodeURIComponent(document.getElementById('driveLink').value);
            fetch('/start?mode=' + mode + '&link=' + link);
        }
        function stopServer() { fetch('/stop'); }
        function sendCmd() {
            const input = document.getElementById('cmd');
            if(!input.value.trim()) return;
            fetch('/send', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'cmd=' + encodeURIComponent(input.value)
            });
            input.value = '';
        }
        setInterval(updateLogs, 1500);
    </script>
</body>
</html>
"""

@app.route('/')
def index(): return render_template_string(HTML_TEMPLATE)

@app.route('/start')
def start():
    mode = request.args.get('mode', 'crossplay')
    drive_url = request.args.get('link', '')
    threading.Thread(target=start_server_logic, args=(mode, drive_url)).start()
    return jsonify({"status": "starting"})

@app.route('/stop')
def stop():
    threading.Thread(target=stop_server_logic).start()
    return jsonify({"status": "stopping"})

@app.route('/logs')
def logs(): return jsonify({"logs": console_logs})

@app.route('/send', methods=['POST'])
def send():
    cmd = request.form.get('cmd', '')
    if server_process and server_process.poll() is None and cmd:
        server_process.stdin.write(cmd + '\n')
        server_process.stdin.flush()
        console_logs.append(f"> {cmd}")
    return jsonify({"status": "sent"})

if __name__ == '__main__':
    print("========================================")
    print("   ⚡ S.HOST DASHBOARD GESTARTET ⚡   ")
    print("   Web-Interface: http://localhost:5000  ")
    print("========================================")
    app.run(host='0.0.0.0', port=5000)
