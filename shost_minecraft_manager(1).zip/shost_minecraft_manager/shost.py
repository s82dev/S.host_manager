from flask import Flask, render_template, request, jsonify
import os
import zipfile
import subprocess

app = Flask(__name__, template_folder='.')

server_process = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/command', methods=['POST'])
def send_command():
    global server_process
    data = request.get_json()
    command = data.get('command', '')

    if server_process and server_process.poll() is None:
        server_process.stdin.write(f"{command}\n".encode())
        server_process.stdin.flush()
        return jsonify({"status": "success", "message": f"Befehl '{command}' gesendet."})
    else:
        print(f"[DEMO-MODUS] Befehl empfangen: {command}")
        return jsonify({"status": "demo", "message": f"Demo-Modus: Befehl '{command}' empfangen."})

@app.route('/api/stop', methods=['POST'])
def stop_and_backup():
    global server_process

    if server_process and server_process.poll() is None:
        server_process.stdin.write("stop\n".encode())
        server_process.stdin.flush()
        server_process.wait()

    world_folder = 'world'
    backup_zip = 'world_backup.zip'

    if os.path.exists(world_folder):
        with zipfile.ZipFile(backup_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(world_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, world_folder)
                    zipf.write(file_path, arcname)
        return jsonify({"status": "success", "message": "Server gestoppt & Welt als 'world_backup.zip' gesichert!"})
    
    return jsonify({"status": "warning", "message": "Server gestoppt, aber kein 'world'-Ordner zum Sichern gefunden."})

if __name__ == '__main__':
    print("⚡ S.HOST Manager gestartet!")
    print("🌐 Öffne http://localhost:5000 in deinem Browser")
    app.run(host='0.0.0.0', port=5000, debug=True)
