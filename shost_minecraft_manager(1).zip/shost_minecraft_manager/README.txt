S.HOST - Minecraft Test-Server Manager
========================================

Inhalt:
- shost.py: Das Python Flask-Backend für die Server-Steuerung und Backups.
- index.html: Die Web-Oberfläche inklusive Whitelist/Blacklist-Steuerung und Mehrsprachenunterstützung.
- requirements.txt: Benötigte Python-Bibliotheken (Flask).

Starten:
1. 'pip install -r requirements.txt' ausführen.
2. 'python shost.py' ausführen.
3. Im Browser http://localhost:5000 aufrufen.
